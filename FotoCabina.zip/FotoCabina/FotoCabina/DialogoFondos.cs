﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace FotoCabina
{
    // Fondos que cambian solos detras de la tira: activar, agregar y quitar
    class DialogoFondos : Form
    {
        readonly CheckedListBox lista;
        readonly PictureBox prev;
        List<string> ids = new List<string>();
        bool cargando;

        public DialogoFondos()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Tema.Fondo;
            Size = new Size(1000, 630);
            ShowInTaskbar = false;
            Paint += (s, e) => Tema.Borde(e.Graphics, Size);

            Controls.Add(new Label
            {
                Text = "FONDOS DE PANTALLA", ForeColor = Tema.Dorado, Font = Tema.Fuente(24),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 12, Width, 56)
            });
            Controls.Add(new Label
            {
                Text = "Marca los fondos que quieres que cambien solos detrás de la tira.",
                ForeColor = Tema.Texto, Font = Tema.Fuente(12, false),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 66, Width, 26)
            });

            lista = new CheckedListBox
            {
                Bounds = new Rectangle(30, 105, 380, 390), Font = Tema.Fuente(15, false),
                BackColor = Tema.Panel, ForeColor = Tema.Texto, BorderStyle = BorderStyle.FixedSingle,
                CheckOnClick = true, IntegralHeight = false
            };
            prev = new PictureBox
            {
                Bounds = new Rectangle(430, 105, 540, 304), SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Black, BorderStyle = BorderStyle.FixedSingle
            };
            Controls.Add(lista);
            Controls.Add(prev);

            Controls.Add(new Label
            {
                Text = "Cambiar cada", ForeColor = Tema.Texto, Font = Tema.Fuente(14),
                TextAlign = ContentAlignment.MiddleLeft, Bounds = new Rectangle(430, 425, 170, 40)
            });
            var nSeg = new NumericUpDown
            {
                Minimum = 3, Maximum = 60, Value = Config.SegFondo, Font = Tema.Fuente(16),
                Bounds = new Rectangle(605, 425, 90, 40), BackColor = Tema.Panel, ForeColor = Color.White
            };
            nSeg.ValueChanged += (s, e) => Config.Set("SegFondo", ((int)nSeg.Value).ToString());
            Controls.Add(nSeg);
            Controls.Add(new Label
            {
                Text = "segundos", ForeColor = Tema.Texto, Font = Tema.Fuente(14),
                TextAlign = ContentAlignment.MiddleLeft, Bounds = new Rectangle(705, 425, 150, 40)
            });

            var cAuto = new CheckBox
            {
                Checked = Config.FondoAuto, Text = "Cambiar fondos automáticamente",
                ForeColor = Tema.DoradoClaro, Font = Tema.Fuente(13), AutoSize = true, Location = new Point(430, 475)
            };
            cAuto.CheckedChanged += (s, e) => Config.Set("FondoAuto", cAuto.Checked.ToString());
            Controls.Add(cAuto);

            var bAgregar = Tema.Boton("AGREGAR FONDO", (s, e) => Agregar(), 15);
            bAgregar.Bounds = new Rectangle(30, 530, 260, 66);
            var bEliminar = Tema.Boton("ELIMINAR", (s, e) => Eliminar(), 15);
            bEliminar.Bounds = new Rectangle(310, 530, 200, 66);
            var bCerrar = Tema.Boton("LISTO", (s, e) => Close(), 15);
            bCerrar.Bounds = new Rectangle(710, 530, 260, 66);
            Controls.Add(bAgregar);
            Controls.Add(bEliminar);
            Controls.Add(bCerrar);

            lista.ItemCheck += (s, e) =>
            {
                if (!cargando && e.Index >= 0 && e.Index < ids.Count)
                    Fondos.Activar(ids[e.Index], e.NewValue == CheckState.Checked);
            };
            lista.SelectedIndexChanged += (s, e) => MostrarVista();
            Cargar(null);
        }

        void Cargar(string seleccionar)
        {
            cargando = true;
            lista.Items.Clear();
            ids = Fondos.Todos();
            foreach (var id in ids)
                lista.Items.Add(Fondos.Nombre(id), Fondos.EstaActivo(id));
            cargando = false;
            int i = ids.IndexOf(seleccionar ?? ids[0]);
            lista.SelectedIndex = i >= 0 ? i : 0;
        }

        void MostrarVista()
        {
            int i = lista.SelectedIndex;
            if (i < 0 || i >= ids.Count) return;
            var nueva = Fondos.Cargar(ids[i]);
            var vieja = prev.Image;
            prev.Image = nueva;
            if (vieja != null) vieja.Dispose();
        }

        void Agregar()
        {
            using (var d = new OpenFileDialog
            {
                Filter = "Imágenes|*.jpg;*.jpeg;*.png;*.bmp",
                Multiselect = true,
                Title = "Elige las imágenes de fondo"
            })
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    Directory.CreateDirectory(Fondos.Carpeta);
                    string ultimo = null;
                    foreach (var f in d.FileNames)
                    {
                        var dest = Path.Combine(Fondos.Carpeta, Path.GetFileName(f));
                        if (!string.Equals(f, dest, StringComparison.OrdinalIgnoreCase)) File.Copy(f, dest, true);
                        ultimo = dest;
                    }
                    Cargar(ultimo);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "No se pudo agregar: " + ex.Message, "FotoCabina");
                }
            }
        }

        void Eliminar()
        {
            int i = lista.SelectedIndex;
            if (i < 0 || i >= ids.Count) return;
            if (ids[i].StartsWith("@"))
            {
                MessageBox.Show(this, "Los fondos incluidos no se eliminan. Desmárcalo para que no aparezca.", "FotoCabina");
                return;
            }
            if (MessageBox.Show(this, "¿Eliminar este fondo?", "FotoCabina", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                File.Delete(ids[i]);
                Fondos.Activar(ids[i], true);
            }
            catch { }
            Cargar(null);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (prev.Image != null) prev.Image.Dispose();
            base.OnFormClosed(e);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if ((keyData & Keys.KeyCode) == Keys.Escape) { Close(); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
