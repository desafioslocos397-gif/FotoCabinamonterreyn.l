﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace FotoCabina
{
    // Elegir / agregar / quitar skins (imagenes) de la pantalla de inicio
    class DialogoSkins : Form
    {
        readonly ListBox lista;
        readonly PictureBox prev;
        readonly Label activo;
        readonly List<string> rutas = new List<string>();

        public DialogoSkins()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Tema.Fondo;
            Size = new Size(940, 590);
            ShowInTaskbar = false;
            Paint += (s, e) => Tema.Borde(e.Graphics, Size);

            Controls.Add(new Label
            {
                Text = "SKINS DE VISUALIZACIÓN", ForeColor = Tema.Dorado, Font = Tema.Fuente(24),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 15, Width, 60)
            });

            lista = new ListBox
            {
                Bounds = new Rectangle(30, 90, 360, 330), Font = Tema.Fuente(15, false),
                BackColor = Tema.Panel, ForeColor = Tema.Texto, BorderStyle = BorderStyle.FixedSingle,
                IntegralHeight = false
            };
            prev = new PictureBox
            {
                Bounds = new Rectangle(410, 90, 500, 330), SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Black, BorderStyle = BorderStyle.FixedSingle
            };
            activo = new Label
            {
                Bounds = new Rectangle(30, 430, 880, 34), ForeColor = Tema.DoradoClaro,
                Font = Tema.Fuente(14), TextAlign = ContentAlignment.MiddleLeft
            };
            Controls.Add(lista);
            Controls.Add(prev);
            Controls.Add(activo);

            AgregarBoton("AGREGAR SKIN", 30, 230, (s, e) => Agregar());
            AgregarBoton("USAR ESTE", 270, 200, (s, e) => Usar());
            AgregarBoton("ELIMINAR", 480, 190, (s, e) => Eliminar());
            AgregarBoton("CERRAR", 680, 230, (s, e) => Close());

            lista.SelectedIndexChanged += (s, e) => MostrarVista();
            Cargar(null);
        }

        void AgregarBoton(string texto, int x, int w, EventHandler click)
        {
            var b = Tema.Boton(texto, click, 15);
            b.Bounds = new Rectangle(x, 485, w, 70);
            Controls.Add(b);
        }

        static bool EsImagen(string f)
        {
            var x = Path.GetExtension(f).ToLower();
            return x == ".jpg" || x == ".jpeg" || x == ".png" || x == ".bmp";
        }

        void Cargar(string seleccionar)
        {
            lista.Items.Clear();
            rutas.Clear();
            lista.Items.Add("Leon Booth (incluido)");
            rutas.Add("");
            try
            {
                if (Directory.Exists(Config.CarpetaSkins))
                {
                    foreach (var f in Directory.GetFiles(Config.CarpetaSkins).Where(EsImagen).OrderBy(x => x))
                    {
                        lista.Items.Add(Path.GetFileNameWithoutExtension(f));
                        rutas.Add(f);
                    }
                }
            }
            catch { }
            int i = rutas.IndexOf(seleccionar ?? Config.Skin);
            lista.SelectedIndex = i >= 0 ? i : 0;
            ActualizarActivo();
        }

        void ActualizarActivo()
        {
            int i = rutas.IndexOf(Config.Skin);
            if (i < 0) i = 0;
            activo.Text = "Skin activo: " + lista.Items[i];
        }

        void MostrarVista()
        {
            int i = lista.SelectedIndex;
            if (i < 0 || i >= rutas.Count) return;
            var nueva = (i == 0) ? Recursos.Embebido("fondo_inicio.jpg") : Recursos.Archivo(rutas[i]);
            var vieja = prev.Image;
            prev.Image = nueva;
            if (vieja != null) vieja.Dispose();
        }

        void Agregar()
        {
            using (var d = new OpenFileDialog
            {
                Filter = "Imágenes|*.jpg;*.jpeg;*.png;*.bmp",
                Multiselect = true,
                Title = "Elige la imagen del skin"
            })
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    Directory.CreateDirectory(Config.CarpetaSkins);
                    string ultimo = null;
                    foreach (var f in d.FileNames)
                    {
                        var dest = Path.Combine(Config.CarpetaSkins, Path.GetFileName(f));
                        if (!string.Equals(f, dest, StringComparison.OrdinalIgnoreCase)) File.Copy(f, dest, true);
                        ultimo = dest;
                    }
                    Cargar(ultimo);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "No se pudo agregar: " + ex.Message, "FotoCabina");
                }
            }
        }

        void Usar()
        {
            int i = lista.SelectedIndex;
            if (i < 0) return;
            Config.Set("Skin", rutas[i]);
            ActualizarActivo();
        }

        void Eliminar()
        {
            int i = lista.SelectedIndex;
            if (i <= 0)
            {
                MessageBox.Show(this, "El skin incluido no se puede eliminar.", "FotoCabina");
                return;
            }
            if (MessageBox.Show(this, "¿Eliminar este skin?", "FotoCabina", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                File.Delete(rutas[i]);
                if (Config.Skin == rutas[i]) Config.Set("Skin", "");
            }
            catch { }
            Cargar(null);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (prev.Image != null) prev.Image.Dispose();
            base.OnFormClosed(e);
        }
    }
}
