﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;

namespace FotoCabina
{
    static class Composicion
    {
        public static Bitmap Crear(List<Bitmap> fotos, Diseno d)
        {
            var dim = d.Dimensiones;
            int W = dim.Width, H = dim.Height;
            var bmp = new Bitmap(W, H);
            bmp.SetResolution(300, 300);
            using (var g = Graphics.FromImage(bmp))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.SmoothingMode = SmoothingMode.HighQuality;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

                DibujarFondo(g, d, W, H);
                var celdas = Celdas(d, fotos.Count, W, H);
                for (int i = 0; i < fotos.Count && i < celdas.Count; i++)
                    DibujarFoto(g, fotos[i], celdas[i], d);
                DibujarPie(g, d, W, H);

                if (!string.IsNullOrEmpty(d.Marco))
                {
                    using (var m = Recursos.Cargar(d.Marco))
                    {
                        if (m != null) g.DrawImage(m, new Rectangle(0, 0, W, H));
                    }
                }
            }
            return bmp;
        }

        static void DibujarFondo(Graphics g, Diseno d, int W, int H)
        {
            var r = new Rectangle(0, 0, W, H);
            if (d.Degradado)
            {
                using (var br = new LinearGradientBrush(r, d.Fondo1, d.Fondo2, LinearGradientMode.Vertical))
                    g.FillRectangle(br, r);
            }
            else
            {
                using (var br = new SolidBrush(d.Fondo1))
                    g.FillRectangle(br, r);
            }
            if (!string.IsNullOrEmpty(d.ImagenFondo))
            {
                using (var im = Recursos.Cargar(d.ImagenFondo))
                {
                    if (im != null)
                    {
                        var src = RecorteCentral(im, r.Width / (float)r.Height);
                        g.DrawImage(im, r, src.X, src.Y, src.Width, src.Height, GraphicsUnit.Pixel);
                    }
                }
            }
        }

        // Rectangulos donde va cada foto
        static List<Rectangle> Celdas(Diseno d, int n, int W, int H)
        {
            int m = d.Margen, s = d.Separacion;
            int x0 = m, y0 = m;
            int aw = Math.Max(50, W - 2 * m);
            int ah = Math.Max(50, H - d.AlturaPie - 2 * m);
            var r = new List<Rectangle>();
            if (n < 1) return r;

            if (d.Distribucion == "Fila")
            {
                int cw = (aw - s * (n - 1)) / n;
                for (int i = 0; i < n; i++)
                    r.Add(new Rectangle(x0 + i * (cw + s), y0, cw, ah));
            }
            else if (d.Distribucion == "Cuadricula")
            {
                int cols = n == 1 ? 1 : 2;
                int rows = (n + cols - 1) / cols;
                int cw = (aw - s * (cols - 1)) / cols;
                int ch = (ah - s * (rows - 1)) / rows;
                for (int i = 0; i < n; i++)
                {
                    int row = i / cols, col = i % cols;
                    int enFila = (row == rows - 1 && n % cols != 0) ? n % cols : cols;
                    int anchoFila = enFila * cw + (enFila - 1) * s;
                    int inicioX = x0 + (aw - anchoFila) / 2;
                    r.Add(new Rectangle(inicioX + col * (cw + s), y0 + row * (ch + s), cw, ch));
                }
            }
            else
            {
                int ch = (ah - s * (n - 1)) / n;
                for (int i = 0; i < n; i++)
                    r.Add(new Rectangle(x0, y0 + i * (ch + s), aw, ch));
            }
            return r;
        }

        static void DibujarFoto(Graphics g, Bitmap f, Rectangle c, Diseno d)
        {
            var src = RecorteCentral(f, c.Width / (float)c.Height);
            using (var path = RectRedondeado(c, d.Esquinas))
            {
                var estado = g.Save();
                g.SetClip(path, CombineMode.Replace);
                g.DrawImage(f, c, src.X, src.Y, src.Width, src.Height, GraphicsUnit.Pixel);
                g.Restore(estado);
                if (d.GrosorBorde > 0)
                {
                    using (var pen = new Pen(d.ColorBorde, d.GrosorBorde))
                        g.DrawPath(pen, path);
                }
            }
        }

        static void DibujarPie(Graphics g, Diseno d, int W, int H)
        {
            if (d.AlturaPie <= 0) return;
            int m = d.Margen;
            int finFotos = H - d.AlturaPie - m;
            int top = finFotos + d.Separacion / 2;
            int bottom = H - m / 2;
            var pie = new Rectangle(m, top, W - 2 * m, Math.Max(10, bottom - top));

            var items = new List<string>();
            if (!string.IsNullOrEmpty(d.Logo)) items.Add("logo");
            if (d.MostrarNombre && Config.Texto.Length > 0) items.Add("nombre");
            if (d.MostrarFecha) items.Add("fecha");
            if (!string.IsNullOrEmpty(d.TextoExtra)) items.Add("extra");
            if (items.Count == 0) return;

            Func<string, float> peso = k => k == "logo" ? 0.55f : (k == "nombre" ? 0.30f : (k == "fecha" ? 0.14f : 0.16f));
            float total = items.Sum(peso);
            float y = pie.Y;

            using (var br = new SolidBrush(d.ColorTexto))
            using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center, FormatFlags = StringFormatFlags.NoWrap })
            {
                foreach (var k in items)
                {
                    float h = pie.Height * peso(k) / total;
                    var celda = new RectangleF(pie.X, y, pie.Width, h);
                    y += h;

                    if (k == "logo")
                    {
                        using (var lg = Recursos.Cargar(d.Logo))
                        {
                            if (lg != null)
                            {
                                float esc = Math.Min(celda.Width / lg.Width, celda.Height / lg.Height);
                                float lw = lg.Width * esc, lh = lg.Height * esc;
                                g.DrawImage(lg, celda.X + (celda.Width - lw) / 2f, celda.Y + (celda.Height - lh) / 2f, lw, lh);
                            }
                        }
                        continue;
                    }

                    string texto = k == "nombre" ? Config.Texto : (k == "fecha" ? DateTime.Now.ToString("dd/MM/yyyy") : d.TextoExtra);
                    using (var f = AjustarFuente(g, texto, d.Fuente, k == "nombre", celda.Width, celda.Height * 0.9f))
                        g.DrawString(texto, f, br, celda, sf);
                }
            }
        }

        static Font AjustarFuente(Graphics g, string texto, string familia, bool negrita, float anchoMax, float altoMax)
        {
            float tam = Math.Max(10f, altoMax);
            var estilo = negrita ? FontStyle.Bold : FontStyle.Regular;
            Font f = CrearFuente(familia, tam, estilo);
            while (tam > 10f)
            {
                var medida = g.MeasureString(texto, f);
                if (medida.Width <= anchoMax && medida.Height <= altoMax) break;
                f.Dispose();
                tam -= 2f;
                f = CrearFuente(familia, tam, estilo);
            }
            return f;
        }

        static Font CrearFuente(string familia, float tam, FontStyle estilo)
        {
            try { return new Font(familia, tam, estilo, GraphicsUnit.Pixel); }
            catch { return new Font("Segoe UI", tam, estilo, GraphicsUnit.Pixel); }
        }

        public static GraphicsPath RectRedondeado(Rectangle r, int radio)
        {
            var p = new GraphicsPath();
            if (radio <= 0) { p.AddRectangle(r); return p; }
            int dm = Math.Max(2, Math.Min(radio * 2, Math.Min(r.Width, r.Height)));
            p.AddArc(r.X, r.Y, dm, dm, 180, 90);
            p.AddArc(r.Right - dm, r.Y, dm, dm, 270, 90);
            p.AddArc(r.Right - dm, r.Bottom - dm, dm, dm, 0, 90);
            p.AddArc(r.X, r.Bottom - dm, dm, dm, 90, 90);
            p.CloseFigure();
            return p;
        }

        static RectangleF RecorteCentral(Bitmap b, float aspecto)
        {
            float w = b.Width, h = b.Height;
            if (w / h > aspecto)
            {
                float nw = h * aspecto;
                return new RectangleF((w - nw) / 2, 0, nw, h);
            }
            float nh = w / aspecto;
            return new RectangleF(0, (h - nh) / 2, w, nh);
        }

        public static void GuardarJpg(Bitmap b, string ruta, long calidad = 95L)
        {
            var codec = ImageCodecInfo.GetImageEncoders().First(c => c.FormatID == ImageFormat.Jpeg.Guid);
            using (var ep = new EncoderParameters(1))
            {
                ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, calidad);
                b.Save(ruta, codec, ep);
            }
        }
    }
}
