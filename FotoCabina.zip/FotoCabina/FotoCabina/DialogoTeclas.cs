﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace FotoCabina
{
    // Asigna la tecla (o boton fisico tipo teclado) de cada accion
    class DialogoTeclas : Form
    {
        readonly string[] nombres = { "INICIAR FOTOS", "IMPRIMIR", "REPETIR", "TERMINAR" };
        readonly Label[] valores = new Label[4];
        readonly Label ayuda;
        int esperando = -1;

        public DialogoTeclas()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Tema.Fondo;
            Size = new Size(800, 600);
            ShowInTaskbar = false;
            Paint += (s, e) => Tema.Borde(e.Graphics, Size);

            Controls.Add(new Label
            {
                Text = "CONFIGURAR TECLADO", ForeColor = Tema.Dorado, Font = Tema.Fuente(24),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 15, Width, 60)
            });
            ayuda = new Label
            {
                ForeColor = Tema.Texto, Font = Tema.Fuente(13, false),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(20, 78, Width - 40, 34)
            };
            Controls.Add(ayuda);

            for (int i = 0; i < 4; i++)
            {
                int idx = i;
                int y = 125 + i * 75;
                Controls.Add(new Label
                {
                    Text = nombres[i], ForeColor = Tema.Texto, Font = Tema.Fuente(20),
                    TextAlign = ContentAlignment.MiddleLeft, Bounds = new Rectangle(40, y, 260, 60)
                });
                valores[i] = new Label
                {
                    ForeColor = Tema.DoradoClaro, BackColor = Tema.Panel, Font = Tema.Fuente(20),
                    TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(310, y, 260, 60)
                };
                Controls.Add(valores[i]);
                var b = Tema.Boton("CAMBIAR", (s, e) => { esperando = idx; Refrescar(); }, 15);
                b.Bounds = new Rectangle(590, y, 170, 60);
                Controls.Add(b);
            }

            var cerrar = Tema.Boton("LISTO", (s, e) => Close(), 18);
            cerrar.Bounds = new Rectangle(250, Height - 100, 300, 65);
            Controls.Add(cerrar);
            Refrescar();
        }

        void Refrescar()
        {
            for (int i = 0; i < 4; i++)
                valores[i].Text = (i == esperando) ? "PRESIONA..." : Config.NombreTecla(Config.TeclaAccion(i));
            ayuda.Text = esperando >= 0
                ? "Presiona ahora el botón o la tecla (Esc para cancelar)"
                : "Elige una acción y presiona CAMBIAR. La tecla M abre el menú.";
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            var k = keyData & Keys.KeyCode;
            if (esperando >= 0)
            {
                if (k == Keys.Escape) { esperando = -1; Refrescar(); return true; }
                if (k == Keys.M) { ayuda.Text = "La tecla M está reservada para el menú. Elige otra."; return true; }
                Config.Set(Config.TeclaClaves[esperando], k.ToString());
                esperando = -1;
                Refrescar();
                return true;
            }
            if (k == Keys.Escape) { Close(); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
