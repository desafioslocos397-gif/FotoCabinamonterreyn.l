﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace FotoCabina
{
    // Pantalla de resultado: fondos animados que cambian solos, la tira con sombra y botones modernos
    class PanelRevision : Control
    {
        public event EventHandler Imprimir;
        public event EventHandler Repetir;
        public event EventHandler Terminar;

        static readonly Random rnd = new Random();
        static readonly string[] textos = { "IMPRIMIR", "REPETIR", "TERMINAR" };

        Bitmap tira, tiraEsc, fondoA, fondoB;
        List<string> ids = new List<string>();
        int indice;
        DateTime cambio = DateTime.Now;
        bool fading;
        float fade;
        string mensaje = "";
        bool mostrarBotones = true;
        int[] acciones = new int[0];
        RectangleF[] rects = new RectangleF[0];
        int hover = -1, presionado = -1;
        readonly Font fuenteBoton = Tema.Fuente(18);
        readonly Font fuenteMensaje = Tema.Fuente(28);
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval = 33 };

        public PanelRevision()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Color.Black;
            timer.Tick += (s, e) => Animar();
            timer.Enabled = true;
        }

        public string Mensaje
        {
            get { return mensaje; }
            set { mensaje = value ?? ""; Invalidate(); }
        }

        public bool MostrarBotones
        {
            get { return mostrarBotones; }
            set { mostrarBotones = value; Invalidate(); }
        }

        bool BotonesVisibles { get { return mostrarBotones && mensaje.Length == 0; } }

        public void SetTira(Bitmap b)
        {
            if (tira != null) { tira.Dispose(); tira = null; }
            if (tiraEsc != null) { tiraEsc.Dispose(); tiraEsc = null; }
            if (b != null) tira = (Bitmap)b.Clone();
            EscalarTira();
            Invalidate();
        }

        public void Iniciar()
        {
            CargarFondos();
        }

        // ---------- Fondos ----------
        void CargarFondos()
        {
            if (fondoA != null) { fondoA.Dispose(); fondoA = null; }
            if (fondoB != null) { fondoB.Dispose(); fondoB = null; }
            fading = false;
            ids = Fondos.Activos();
            indice = rnd.Next(ids.Count);
            fondoA = Cubrir(Fondos.Cargar(ids[indice]));
            cambio = DateTime.Now;
            Invalidate();
        }

        Bitmap Cubrir(Bitmap src)
        {
            if (src == null) return null;
            if (Width < 2 || Height < 2) { src.Dispose(); return null; }
            var dest = new Bitmap(Width, Height);
            float esc = Math.Max(Width / (float)src.Width, Height / (float)src.Height);
            float sw = Width / esc, sh = Height / esc;
            float sx = (src.Width - sw) / 2f, sy = (src.Height - sh) / 2f;
            using (var g = Graphics.FromImage(dest))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.DrawImage(src, new RectangleF(0, 0, Width, Height), new RectangleF(sx, sy, sw, sh), GraphicsUnit.Pixel);
            }
            src.Dispose();
            return dest;
        }

        void Animar()
        {
            if (!Visible) return;
            if (fading)
            {
                fade = (float)((DateTime.Now - cambio).TotalSeconds / 1.2);
                if (fade >= 1f)
                {
                    if (fondoA != null) fondoA.Dispose();
                    fondoA = fondoB;
                    fondoB = null;
                    fading = false;
                    fade = 0f;
                    cambio = DateTime.Now;
                }
                Invalidate();
            }
            else if (ids.Count > 1 && Config.FondoAuto && (DateTime.Now - cambio).TotalSeconds >= Config.SegFondo)
            {
                indice = (indice + 1) % ids.Count;
                var siguiente = Cubrir(Fondos.Cargar(ids[indice]));
                if (siguiente != null)
                {
                    fondoB = siguiente;
                    fading = true;
                    fade = 0f;
                }
                cambio = DateTime.Now;
            }
        }

        // ---------- Tira ----------
        RectangleF AreaTira()
        {
            return new RectangleF(20, 20, Math.Max(10, Width - 40), Math.Max(10, Height - 20 - 150));
        }

        void EscalarTira()
        {
            if (tira == null || Width < 10 || Height < 10) return;
            var area = AreaTira();
            float esc = Math.Min(area.Width / tira.Width, area.Height / tira.Height);
            int w = Math.Max(1, (int)(tira.Width * esc));
            int h = Math.Max(1, (int)(tira.Height * esc));
            if (tiraEsc != null) tiraEsc.Dispose();
            tiraEsc = new Bitmap(w, h);
            using (var g = Graphics.FromImage(tiraEsc))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.DrawImage(tira, 0, 0, w, h);
            }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (Width > 10 && Height > 10)
            {
                EscalarTira();
                if (Visible) CargarFondos();
            }
        }

        // ---------- Dibujo ----------
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Color.Black);
            g.SmoothingMode = SmoothingMode.AntiAlias;

            if (fondoA != null) g.DrawImage(fondoA, 0, 0, Width, Height);
            if (fading && fondoB != null)
            {
                using (var ia = new ImageAttributes())
                {
                    var cm = new ColorMatrix();
                    cm.Matrix33 = Math.Min(1f, Math.Max(0f, fade));
                    ia.SetColorMatrix(cm, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
                    g.DrawImage(fondoB, new Rectangle(0, 0, Width, Height), 0, 0, fondoB.Width, fondoB.Height, GraphicsUnit.Pixel, ia);
                }
            }

            if (tiraEsc != null)
            {
                var a = AreaTira();
                int x = (int)(a.X + (a.Width - tiraEsc.Width) / 2f);
                int y = (int)(a.Y + (a.Height - tiraEsc.Height) / 2f);
                for (int i = 16; i >= 1; i--)
                {
                    using (var br = new SolidBrush(Color.FromArgb(9, 0, 0, 0)))
                        g.FillRectangle(br, x - i + 6, y - i + 10, tiraEsc.Width + 2 * i, tiraEsc.Height + 2 * i);
                }
                g.DrawImage(tiraEsc, x, y, tiraEsc.Width, tiraEsc.Height);
                using (var pen = new Pen(Color.FromArgb(200, Tema.Dorado), 2))
                    g.DrawRectangle(pen, x, y, tiraEsc.Width - 1, tiraEsc.Height - 1);
            }

            if (mensaje.Length > 0)
            {
                var sz = g.MeasureString(mensaje, fuenteMensaje);
                float w = sz.Width + 80f, h = 84f;
                var rr = new Rectangle((int)((Width - w) / 2f), (int)(Height - h - 50f), (int)w, (int)h);
                using (var path = Composicion.RectRedondeado(rr, 42))
                using (var fondo = new SolidBrush(Color.FromArgb(215, 18, 18, 18)))
                using (var pen = new Pen(Tema.Dorado, 2.5f))
                {
                    g.FillPath(fondo, path);
                    g.DrawPath(pen, path);
                }
                using (var br = new SolidBrush(Tema.DoradoClaro))
                using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                    g.DrawString(mensaje, fuenteMensaje, br, rr, sf);
            }
            else if (mostrarBotones)
            {
                CalcularBotones();
                for (int i = 0; i < rects.Length; i++)
                    DibujarBoton(g, rects[i], textos[acciones[i]], acciones[i], acciones[i] == 0, i == hover, i == presionado);
            }
        }

        void CalcularBotones()
        {
            var acc = new List<int>();
            if (Config.Imprimir) acc.Add(0);
            acc.Add(1);
            acc.Add(2);
            int n = acc.Count;
            float gap = 24f, bh = 76f;
            float bw = Math.Min(300f, (Width - 80f - gap * (n - 1)) / n);
            float total = n * bw + (n - 1) * gap;
            float x = (Width - total) / 2f;
            float y = Height - bh - 40f;
            acciones = acc.ToArray();
            rects = new RectangleF[n];
            for (int i = 0; i < n; i++)
            {
                rects[i] = new RectangleF(x, y, bw, bh);
                x += bw + gap;
            }
        }

        void DibujarBoton(Graphics g, RectangleF r, string texto, int icono, bool primario, bool hov, bool pres)
        {
            if (pres) r.Offset(0, 3);
            var ri = Rectangle.Round(r);

            using (var sombra = Composicion.RectRedondeado(new Rectangle(ri.X, ri.Y + 6, ri.Width, ri.Height), ri.Height / 2))
            using (var bsombra = new SolidBrush(Color.FromArgb(90, 0, 0, 0)))
                g.FillPath(bsombra, sombra);

            using (var path = Composicion.RectRedondeado(ri, ri.Height / 2))
            {
                Color colorTexto;
                if (primario)
                {
                    using (var lg = new LinearGradientBrush(ri, Color.FromArgb(250, 224, 130), Color.FromArgb(198, 154, 30), 90f))
                        g.FillPath(lg, path);
                    colorTexto = Color.FromArgb(40, 28, 0);
                }
                else
                {
                    using (var bf = new SolidBrush(Color.FromArgb(215, 18, 18, 18)))
                        g.FillPath(bf, path);
                    using (var pen = new Pen(Tema.Dorado, 2.5f))
                        g.DrawPath(pen, path);
                    colorTexto = Tema.DoradoClaro;
                }
                if (hov || pres)
                {
                    using (var ov = new SolidBrush(Color.FromArgb(pres ? 50 : 35, 255, 255, 255)))
                        g.FillPath(ov, path);
                }

                float isz = ri.Height * 0.42f;
                var ir = new RectangleF(ri.X + ri.Height * 0.5f, ri.Y + (ri.Height - isz) / 2f, isz, isz);
                DibujarIcono(g, icono, ir, colorTexto);

                var tr = new RectangleF(ri.X + ri.Height * 0.95f, ri.Y, ri.Width - ri.Height * 1.2f, ri.Height);
                using (var br = new SolidBrush(colorTexto))
                using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center, FormatFlags = StringFormatFlags.NoWrap })
                    g.DrawString(texto, fuenteBoton, br, tr, sf);
            }
        }

        static void DibujarIcono(Graphics g, int tipo, RectangleF r, Color c)
        {
            float w = r.Width, h = r.Height;
            using (var pen = new Pen(c, Math.Max(2f, w / 10f)))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                pen.LineJoin = LineJoin.Round;
                if (tipo == 0)
                {
                    // impresora
                    g.DrawRectangle(pen, r.X + w * 0.25f, r.Y + h * 0.05f, w * 0.5f, h * 0.30f);
                    g.DrawRectangle(pen, r.X, r.Y + h * 0.35f, w, h * 0.35f);
                    g.DrawRectangle(pen, r.X + w * 0.25f, r.Y + h * 0.55f, w * 0.5f, h * 0.40f);
                }
                else if (tipo == 1)
                {
                    // repetir: arco con flecha
                    var arco = new RectangleF(r.X + w * 0.12f, r.Y + h * 0.12f, w * 0.76f, h * 0.76f);
                    g.DrawArc(pen, arco, -60f, 290f);
                    double ang = (-60.0 + 290.0) * Math.PI / 180.0;
                    float cx = arco.X + arco.Width / 2f, cy = arco.Y + arco.Height / 2f, rad = arco.Width / 2f;
                    float ex = cx + rad * (float)Math.Cos(ang), ey = cy + rad * (float)Math.Sin(ang);
                    float tx = -(float)Math.Sin(ang), ty = (float)Math.Cos(ang);
                    float nx = -ty, ny = tx;
                    float s = w * 0.24f;
                    var pts = new[]
                    {
                        new PointF(ex + tx * s, ey + ty * s),
                        new PointF(ex + nx * s * 0.65f, ey + ny * s * 0.65f),
                        new PointF(ex - nx * s * 0.65f, ey - ny * s * 0.65f)
                    };
                    using (var br = new SolidBrush(c))
                        g.FillPolygon(br, pts);
                }
                else
                {
                    // palomita
                    g.DrawLines(pen, new[]
                    {
                        new PointF(r.X + w * 0.08f, r.Y + h * 0.55f),
                        new PointF(r.X + w * 0.38f, r.Y + h * 0.85f),
                        new PointF(r.X + w * 0.94f, r.Y + h * 0.18f)
                    });
                }
            }
        }

        // ---------- Mouse / tactil ----------
        int Golpe(Point p)
        {
            for (int i = 0; i < rects.Length; i++)
                if (rects[i].Contains(p.X, p.Y)) return i;
            return -1;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (!BotonesVisibles) return;
            CalcularBotones();
            int h = Golpe(e.Location);
            if (h != hover)
            {
                hover = h;
                Cursor = h >= 0 ? Cursors.Hand : Cursors.Default;
                Invalidate();
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (!BotonesVisibles) return;
            CalcularBotones();
            presionado = Golpe(e.Location);
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (!BotonesVisibles) return;
            CalcularBotones();
            int h = Golpe(e.Location);
            int p = presionado;
            presionado = -1;
            Invalidate();
            if (h >= 0 && h == p) Disparar(acciones[h]);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            hover = -1;
            presionado = -1;
            Invalidate();
        }

        void Disparar(int accion)
        {
            EventHandler h = accion == 0 ? Imprimir : (accion == 1 ? Repetir : Terminar);
            if (h != null) h(this, EventArgs.Empty);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                timer.Dispose();
                fuenteBoton.Dispose();
                fuenteMensaje.Dispose();
                if (tira != null) tira.Dispose();
                if (tiraEsc != null) tiraEsc.Dispose();
                if (fondoA != null) fondoA.Dispose();
                if (fondoB != null) fondoB.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
