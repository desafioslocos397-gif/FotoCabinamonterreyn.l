﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace FotoCabina
{
    // Lista de disenos de tira: elegir, crear nuevos a partir de otro y editarlos
    class DialogoDisenos : Form
    {
        readonly ListBox lista;
        readonly PictureBox prev;
        readonly Label activo;
        List<Diseno> disenos = new List<Diseno>();

        public DialogoDisenos()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Tema.Fondo;
            Size = new Size(1100, 660);
            ShowInTaskbar = false;
            Paint += (s, e) => Tema.Borde(e.Graphics, Size);

            Controls.Add(new Label
            {
                Text = "DISEÑOS DE TIRA", ForeColor = Tema.Dorado, Font = Tema.Fuente(24),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 12, Width, 56)
            });

            lista = new ListBox
            {
                Bounds = new Rectangle(30, 85, 400, 400), Font = Tema.Fuente(15, false),
                BackColor = Tema.Panel, ForeColor = Tema.Texto, BorderStyle = BorderStyle.FixedSingle,
                IntegralHeight = false
            };
            prev = new PictureBox
            {
                Bounds = new Rectangle(450, 85, 620, 400), SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.FromArgb(30, 30, 30), BorderStyle = BorderStyle.FixedSingle
            };
            activo = new Label
            {
                Bounds = new Rectangle(30, 495, 1040, 34), ForeColor = Tema.DoradoClaro,
                Font = Tema.Fuente(14), TextAlign = ContentAlignment.MiddleLeft
            };
            Controls.Add(lista);
            Controls.Add(prev);
            Controls.Add(activo);

            AgregarBoton("USAR ESTE", 30, (s, e) => Usar());
            AgregarBoton("NUEVO", 232, (s, e) => Nuevo());
            AgregarBoton("EDITAR", 434, (s, e) => EditarSeleccionado());
            AgregarBoton("ELIMINAR", 636, (s, e) => Eliminar());
            AgregarBoton("LISTO", 838, (s, e) => Close());

            lista.SelectedIndexChanged += (s, e) => MostrarVista();
            Cargar(null);
        }

        void AgregarBoton(string texto, int x, EventHandler click)
        {
            var b = Tema.Boton(texto, click, 14);
            b.Bounds = new Rectangle(x, 550, 192, 70);
            Controls.Add(b);
        }

        void Cargar(string seleccionarId)
        {
            disenos = Disenos.Todos();
            string act = Config.DisenoActivo;
            lista.Items.Clear();
            foreach (var d in disenos)
                lista.Items.Add(d.Nombre + (d.Incluido ? "  (incluido)" : "") + (d.Id == act ? "  ✓" : ""));
            string buscar = seleccionarId ?? act;
            int i = disenos.FindIndex(x => x.Id == buscar);
            lista.SelectedIndex = i >= 0 ? i : 0;
            activo.Text = "Diseño activo: " + Disenos.Activo().Nombre;
        }

        Diseno Seleccionado()
        {
            int i = lista.SelectedIndex;
            return (i >= 0 && i < disenos.Count) ? disenos[i] : null;
        }

        void MostrarVista()
        {
            var d = Seleccionado();
            if (d == null) return;
            var fotos = Disenos.Muestra(Config.NumFotos);
            try
            {
                var bmp = Composicion.Crear(fotos, d);
                var vieja = prev.Image;
                prev.Image = bmp;
                if (vieja != null) vieja.Dispose();
            }
            catch { }
            finally
            {
                foreach (var f in fotos) f.Dispose();
            }
        }

        void Usar()
        {
            var d = Seleccionado();
            if (d == null) return;
            Config.Set("DisenoActivo", d.Id);
            Cargar(d.Id);
        }

        void Nuevo()
        {
            var d = Seleccionado();
            if (d == null) return;
            var copia = d.Clonar();
            copia.Id = "";
            copia.Incluido = false;
            copia.Nombre = d.Nombre + " (copia)";
            Editar(copia);
        }

        void EditarSeleccionado()
        {
            var d = Seleccionado();
            if (d == null) return;
            if (d.Incluido) { Nuevo(); return; }
            Editar(d.Clonar());
        }

        void Editar(Diseno trabajo)
        {
            using (var ed = new DialogoDiseno(trabajo))
            {
                if (ed.ShowDialog(this) == DialogResult.OK) Cargar(trabajo.Id);
            }
        }

        void Eliminar()
        {
            var d = Seleccionado();
            if (d == null) return;
            if (d.Incluido)
            {
                MessageBox.Show(this, "Los diseños incluidos no se eliminan. Usa NUEVO para hacer tu propia copia.", "FotoCabina");
                return;
            }
            if (MessageBox.Show(this, "¿Eliminar este diseño?", "FotoCabina", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            Disenos.Eliminar(d);
            Cargar(null);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (prev.Image != null) prev.Image.Dispose();
            base.OnFormClosed(e);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if ((keyData & Keys.KeyCode) == Keys.Escape) { Close(); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
