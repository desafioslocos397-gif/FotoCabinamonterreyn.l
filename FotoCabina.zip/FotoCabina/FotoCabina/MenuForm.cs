﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace FotoCabina
{
    class MenuForm : Form
    {
        public bool CerrarPrograma;

        public MenuForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Tema.Fondo;
            ShowInTaskbar = false;
            Size = new Size(1100, 570);
            Paint += (s, e) => Tema.Borde(e.Graphics, Size);

            Controls.Add(new Label
            {
                Text = "LEON BOOTH", ForeColor = Tema.DoradoClaro, Font = Tema.Fuente(13),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 16, Width, 28)
            });
            Controls.Add(new Label
            {
                Text = "MENÚ", ForeColor = Tema.Dorado, Font = Tema.Fuente(30),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 42, Width, 60)
            });

            string[] textos =
            {
                "CONFIGURAR TECLADO", "NOMBRE DEL EVENTO",
                "DISEÑOS DE TIRA", "FONDOS DE PANTALLA",
                "SKINS DE INICIO", "CONFIGURACIÓN GENERAL",
                "CERRAR MENÚ", "CERRAR PROGRAMA",
                "APAGAR PC"
            };
            EventHandler[] acciones =
            {
                Teclado, Nombre, DisenosTira, FondosPantalla, Skins, General,
                (s, e) => Close(), CerrarProg, Apagar
            };
            for (int i = 0; i < textos.Length; i++)
            {
                int x = 40 + (i % 2) * 520;
                if (i == textos.Length - 1) x = (Width - 500) / 2;
                var b = Tema.Boton(textos[i], acciones[i], 15);
                b.Bounds = new Rectangle(x, 120 + (i / 2) * 78, 500, 64);
                Controls.Add(b);
            }
        }

        void DisenosTira(object s, EventArgs e)
        {
            using (var d = new DialogoDisenos()) d.ShowDialog(this);
        }

        void FondosPantalla(object s, EventArgs e)
        {
            using (var d = new DialogoFondos()) d.ShowDialog(this);
        }

        void Teclado(object s, EventArgs e)
        {
            using (var d = new DialogoTeclas()) d.ShowDialog(this);
        }

        void Nombre(object s, EventArgs e)
        {
            using (var d = new DialogoTexto("NOMBRE DEL EVENTO", Config.Texto))
            {
                if (d.ShowDialog(this) == DialogResult.OK && d.Valor.Length > 0)
                    Config.Set("Texto", d.Valor);
            }
        }

        void Skins(object s, EventArgs e)
        {
            using (var d = new DialogoSkins()) d.ShowDialog(this);
        }

        void General(object s, EventArgs e)
        {
            using (var d = new DialogoGeneral()) d.ShowDialog(this);
        }

        void CerrarProg(object s, EventArgs e)
        {
            if (MessageBox.Show(this, "¿Cerrar el programa?", "FotoCabina",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                CerrarPrograma = true;
                Close();
            }
        }

        void Apagar(object s, EventArgs e)
        {
            if (MessageBox.Show(this, "¿Apagar la PC? Se apagará en 10 segundos.", "FotoCabina",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    Process.Start(new ProcessStartInfo("shutdown", "/s /t 10")
                    {
                        CreateNoWindow = true,
                        UseShellExecute = false
                    });
                }
                catch { }
                CerrarPrograma = true;
                Close();
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            var k = keyData & Keys.KeyCode;
            if (k == Keys.Escape || k == Keys.M) { Close(); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
