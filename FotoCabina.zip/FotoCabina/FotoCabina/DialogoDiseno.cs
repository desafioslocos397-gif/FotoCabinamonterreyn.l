﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace FotoCabina
{
    // Editor de un diseno de tira con vista previa en vivo
    class DialogoDiseno : Form
    {
        readonly Diseno d;
        readonly PictureBox prev;
        readonly Panel pnl;
        readonly System.Windows.Forms.Timer deb = new System.Windows.Forms.Timer { Interval = 180 };
        int y = 6;

        static readonly string[] TamanoClaves = { "Tira", "PostalV", "PostalH", "Cuadrada" };
        static readonly string[] TamanoNombres = { "Tira 2x6", "Postal vertical 4x6", "Postal horizontal 6x4", "Cuadrada 4x4" };
        static readonly string[] DistribClaves = { "Columna", "Fila", "Cuadricula" };
        static readonly string[] DistribNombres = { "Columna", "Fila", "Cuadrícula" };
        static readonly string[] Fuentes =
        {
            "Segoe UI", "Arial", "Georgia", "Times New Roman", "Impact",
            "Comic Sans MS", "Courier New", "Trebuchet MS", "Verdana"
        };

        public DialogoDiseno(Diseno original)
        {
            d = original;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Tema.Fondo;
            Size = new Size(1200, 720);
            ShowInTaskbar = false;
            Paint += (s, e) => Tema.Borde(e.Graphics, Size);

            Controls.Add(new Label
            {
                Text = "EDITAR DISEÑO DE TIRA", ForeColor = Tema.Dorado, Font = Tema.Fuente(24),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 12, Width, 56)
            });

            pnl = new Panel { Bounds = new Rectangle(20, 80, 580, 540), AutoScroll = true, BackColor = Tema.Fondo };
            Controls.Add(pnl);
            prev = new PictureBox
            {
                Bounds = new Rectangle(620, 80, 560, 540), SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.FromArgb(30, 30, 30), BorderStyle = BorderStyle.FixedSingle
            };
            Controls.Add(prev);

            // --- nombre ---
            var bNombre = Tema.Boton(d.Nombre, null, 13);
            bNombre.Click += (s, e) =>
            {
                using (var t = new DialogoTexto("NOMBRE DEL DISEÑO", d.Nombre))
                {
                    if (t.ShowDialog(this) == DialogResult.OK && t.Valor.Length > 0)
                    {
                        d.Nombre = t.Valor;
                        bNombre.Text = d.Nombre;
                    }
                }
            };
            Fila("Nombre", bNombre, 330);

            // --- forma ---
            FilaCombo("Tamaño", TamanoNombres, Array.IndexOf(TamanoClaves, d.Tamano), i => d.Tamano = TamanoClaves[i]);
            FilaCombo("Distribución de fotos", DistribNombres, Array.IndexOf(DistribClaves, d.Distribucion), i => d.Distribucion = DistribClaves[i]);

            // --- fondo ---
            FilaColor("Color de fondo", () => d.Fondo1, c => d.Fondo1 = c);
            FilaCheck("Fondo degradado", d.Degradado, v => d.Degradado = v);
            FilaColor("Segundo color (degradado)", () => d.Fondo2, c => d.Fondo2 = c);
            FilaImagen("Imagen de fondo", () => d.ImagenFondo, v => d.ImagenFondo = v);
            FilaImagen("Marco (PNG transparente)", () => d.Marco, v => d.Marco = v);

            // --- pie: logo y textos ---
            FilaImagen("Logo en el pie", () => d.Logo, v => d.Logo = v);
            FilaCheck("Mostrar nombre del evento", d.MostrarNombre, v => d.MostrarNombre = v);
            FilaCheck("Mostrar fecha", d.MostrarFecha, v => d.MostrarFecha = v);

            var bExtra = Tema.Boton(string.IsNullOrEmpty(d.TextoExtra) ? "(ninguno)" : d.TextoExtra, null, 12);
            bExtra.Click += (s, e) =>
            {
                using (var t = new DialogoTexto("TEXTO EXTRA (ej. ¡Gracias por venir!)", d.TextoExtra))
                {
                    if (t.ShowDialog(this) == DialogResult.OK)
                    {
                        d.TextoExtra = t.Valor;
                        bExtra.Text = d.TextoExtra.Length == 0 ? "(ninguno)" : d.TextoExtra;
                        Cambio();
                    }
                }
            };
            Fila("Texto extra", bExtra, 330);

            FilaColor("Color del texto", () => d.ColorTexto, c => d.ColorTexto = c);
            FilaCombo("Letra", Fuentes, Math.Max(0, Array.IndexOf(Fuentes, d.Fuente)), i => d.Fuente = Fuentes[i]);

            // --- fotos ---
            FilaColor("Color del borde de fotos", () => d.ColorBorde, c => d.ColorBorde = c);
            FilaNum("Grosor del borde", 0, 30, d.GrosorBorde, v => d.GrosorBorde = v);
            FilaNum("Esquinas redondeadas", 0, 120, d.Esquinas, v => d.Esquinas = v);
            FilaNum("Margen", 0, 120, d.Margen, v => d.Margen = v);
            FilaNum("Separación entre fotos", 0, 120, d.Separacion, v => d.Separacion = v);
            FilaNum("Alto del pie", 0, 600, d.AlturaPie, v => d.AlturaPie = v);

            // --- botones ---
            var guardar = Tema.Boton("GUARDAR", (s, e) =>
            {
                Disenos.Guardar(d);
                DialogResult = DialogResult.OK;
            }, 18);
            guardar.Bounds = new Rectangle(620, 636, 270, 64);
            var cancelar = Tema.Boton("CANCELAR", (s, e) => { DialogResult = DialogResult.Cancel; }, 18);
            cancelar.Bounds = new Rectangle(910, 636, 270, 64);
            Controls.Add(guardar);
            Controls.Add(cancelar);

            deb.Tick += (s, e) => { deb.Stop(); Render(); };
            Shown += (s, e) => Render();
        }

        void Cambio()
        {
            deb.Stop();
            deb.Start();
        }

        void Render()
        {
            var fotos = Disenos.Muestra(Config.NumFotos);
            try
            {
                var bmp = Composicion.Crear(fotos, d);
                var vieja = prev.Image;
                prev.Image = bmp;
                if (vieja != null) vieja.Dispose();
            }
            catch { }
            finally
            {
                foreach (var f in fotos) f.Dispose();
            }
        }

        // ---------- filas de controles ----------
        void Fila(string etiqueta, Control c, int ancho)
        {
            pnl.Controls.Add(new Label
            {
                Text = etiqueta, ForeColor = Tema.Texto, Font = Tema.Fuente(12),
                TextAlign = ContentAlignment.MiddleLeft, Bounds = new Rectangle(0, y, 230, 40)
            });
            c.Bounds = new Rectangle(235, y, ancho, 40);
            pnl.Controls.Add(c);
            y += 48;
        }

        void FilaCombo(string etiqueta, string[] items, int sel, Action<int> asignar)
        {
            var c = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList, Font = Tema.Fuente(13, false),
                BackColor = Tema.Panel, ForeColor = Color.White
            };
            c.Items.AddRange(items);
            c.SelectedIndex = Math.Max(0, sel);
            c.SelectedIndexChanged += (s, e) => { asignar(c.SelectedIndex); Cambio(); };
            Fila(etiqueta, c, 300);
        }

        void FilaCheck(string etiqueta, bool valor, Action<bool> asignar)
        {
            var c = new CheckBox { Checked = valor, Text = "Sí", ForeColor = Tema.DoradoClaro, Font = Tema.Fuente(13) };
            c.CheckedChanged += (s, e) => { asignar(c.Checked); Cambio(); };
            Fila(etiqueta, c, 120);
        }

        void FilaNum(string etiqueta, int min, int max, int valor, Action<int> asignar)
        {
            var n = new NumericUpDown
            {
                Minimum = min, Maximum = max, Value = Math.Max(min, Math.Min(max, valor)),
                Font = Tema.Fuente(14), BackColor = Tema.Panel, ForeColor = Color.White
            };
            n.ValueChanged += (s, e) => { asignar((int)n.Value); Cambio(); };
            Fila(etiqueta, n, 120);
        }

        void FilaColor(string etiqueta, Func<Color> obtener, Action<Color> asignar)
        {
            var p = new Panel { BackColor = obtener(), BorderStyle = BorderStyle.FixedSingle, Cursor = Cursors.Hand };
            p.Click += (s, e) =>
            {
                using (var cd = new ColorDialog { Color = obtener(), FullOpen = true })
                {
                    if (cd.ShowDialog(this) == DialogResult.OK)
                    {
                        asignar(cd.Color);
                        p.BackColor = cd.Color;
                        Cambio();
                    }
                }
            };
            Fila(etiqueta, p, 120);
        }

        void FilaImagen(string etiqueta, Func<string> obtener, Action<string> asignar)
        {
            pnl.Controls.Add(new Label
            {
                Text = etiqueta, ForeColor = Tema.Texto, Font = Tema.Fuente(12),
                TextAlign = ContentAlignment.MiddleLeft, Bounds = new Rectangle(0, y, 230, 40)
            });
            var elegir = Tema.Boton(string.IsNullOrEmpty(obtener()) ? "ELEGIR..." : "CAMBIAR...", null, 11);
            var quitar = Tema.Boton("QUITAR", null, 11);
            elegir.Click += (s, e) =>
            {
                using (var o = new OpenFileDialog { Filter = "Imágenes|*.png;*.jpg;*.jpeg;*.bmp", Title = etiqueta })
                {
                    if (o.ShowDialog(this) != DialogResult.OK) return;
                    try
                    {
                        asignar(Disenos.CopiarImagen(o.FileName));
                        elegir.Text = "CAMBIAR...";
                        Cambio();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, ex.Message, "FotoCabina");
                    }
                }
            };
            quitar.Click += (s, e) =>
            {
                asignar("");
                elegir.Text = "ELEGIR...";
                Cambio();
            };
            elegir.Bounds = new Rectangle(235, y, 170, 40);
            quitar.Bounds = new Rectangle(415, y, 120, 40);
            pnl.Controls.Add(elegir);
            pnl.Controls.Add(quitar);
            y += 48;
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            deb.Stop();
            deb.Dispose();
            if (prev.Image != null) prev.Image.Dispose();
            base.OnFormClosed(e);
        }
    }
}
