﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;
using AForge.Video.DirectShow;

namespace FotoCabina
{
    public class MainForm : Form
    {
        enum Estado { Inicio, Capturando, Revision }

        static readonly Random rnd = new Random();
        static readonly string[] Graciosas =
        {
            "¡Esa sonrisa vale oro!",
            "¡Pon tu mejor cara de galán!",
            "¡Cuidado, que sale el pajarito!",
            "¡Haz una cara bien chistosa!",
            "¡Ahora una pose de modelo!",
            "¡Eso es, qué elegancia!",
            "¡Saca tu mejor baile!",
            "¡Cara de misterio, por favor!"
        };
        static readonly string[] Numeros = { "cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez" };

        Estado estado = Estado.Inicio;
        VideoCaptureDevice cam;
        Bitmap ultimoFrame;
        readonly object lk = new object();
        int pintando = 0;

        PictureBox vista;
        PanelInicio inicio;
        PanelRevision revision;
        Bitmap tira;
        System.Windows.Forms.Timer timerRevision;
        string mensaje = "";
        float mensajeTam = 60;

        public MainForm()
        {
            Text = "FotoCabina";
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            BackColor = Color.Black;
            DoubleBuffered = true;

            vista = new PictureBox { Dock = DockStyle.Fill, SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Black };
            vista.Paint += PintarMensaje;

            inicio = new PanelInicio { Dock = DockStyle.Fill };
            inicio.Click += async (s, e) => { if (estado == Estado.Inicio) await Sesion(); };

            revision = new PanelRevision { Dock = DockStyle.Fill };
            revision.Imprimir += (s, e) => ImprimirTira();
            revision.Repetir += async (s, e) => await Sesion();
            revision.Terminar += (s, e) => IrAInicio();

            Controls.Add(vista);
            Controls.Add(inicio);
            Controls.Add(revision);

            timerRevision = new System.Windows.Forms.Timer();
            timerRevision.Tick += (s, e) => { timerRevision.Stop(); if (estado == Estado.Revision) IrAInicio(); };

            Shown += (s, e) => IniciarCamara();
            FormClosing += (s, e) => DetenerCamara();
            Pantalla();
        }

        // ---------- Teclas (botones fisicos y menu) ----------
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            var k = keyData & Keys.KeyCode;

            if (keyData == (Keys.Control | Keys.Q)) { Close(); return true; }

            if (estado != Estado.Capturando && k == Keys.M)
            {
                BeginInvoke(new Action(AbrirMenu));
                return true;
            }

            if (estado == Estado.Inicio && k == Config.TeclaAccion(0))
            {
                var t = Sesion();
                return true;
            }
            if (estado == Estado.Revision)
            {
                if (Config.Imprimir && k == Config.TeclaAccion(1)) { ImprimirTira(); return true; }
                if (k == Config.TeclaAccion(2)) { var t = Sesion(); return true; }
                if (k == Config.TeclaAccion(3)) { IrAInicio(); return true; }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        void AbrirMenu()
        {
            if (estado == Estado.Capturando) return;
            bool cerrar;
            timerRevision.Stop();
            using (var m = new MenuForm())
            {
                m.ShowDialog(this);
                cerrar = m.CerrarPrograma;
            }
            inicio.RecargarSkin();
            if (cerrar) { Close(); return; }
            if (estado == Estado.Revision)
            {
                revision.Iniciar();
                timerRevision.Start();
            }
        }

        // ---------- Pantallas ----------
        void Pantalla()
        {
            inicio.Visible = (estado == Estado.Inicio);
            vista.Visible = (estado == Estado.Capturando);
            revision.Visible = (estado == Estado.Revision);
        }

        void Mensaje(string texto, float tam)
        {
            mensaje = texto;
            mensajeTam = tam;
            vista.Invalidate();
        }

        void PintarMensaje(object sender, PaintEventArgs e)
        {
            if (string.IsNullOrEmpty(mensaje)) return;
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float px = mensajeTam * g.DpiY / 72f;
            using (var ff = new FontFamily("Segoe UI"))
            using (var path = new GraphicsPath())
            using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
            {
                path.AddString(mensaje, ff, (int)FontStyle.Bold, px, new RectangleF(0, 0, vista.Width, vista.Height), sf);
                using (var pen = new Pen(Color.Black, Math.Max(4f, px / 16f)) { LineJoin = LineJoin.Round })
                    g.DrawPath(pen, path);
                using (var br = new SolidBrush(Tema.DoradoClaro))
                    g.FillPath(br, path);
            }
        }

        // ---------- Camara ----------
        void IniciarCamara()
        {
            try
            {
                var dev = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (dev.Count == 0)
                {
                    MessageBox.Show("No se encontró ninguna cámara conectada.", "FotoCabina");
                    Close();
                    return;
                }
                cam = new VideoCaptureDevice(dev[Math.Min(Config.Camara, dev.Count - 1)].MonikerString);
                var caps = cam.VideoCapabilities;
                if (caps.Length > 0)
                {
                    var mejor = caps.Where(c => c.FrameSize.Width <= 1280)
                                    .OrderByDescending(c => c.FrameSize.Width * c.FrameSize.Height)
                                    .FirstOrDefault() ?? caps[0];
                    cam.VideoResolution = mejor;
                }
                cam.NewFrame += OnFrame;
                cam.Start();
                IrAInicio();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al iniciar la cámara:\n" + ex.Message, "FotoCabina");
                Close();
            }
        }

        void DetenerCamara()
        {
            try
            {
                if (cam != null && cam.IsRunning)
                {
                    cam.NewFrame -= OnFrame;
                    cam.SignalToStop();
                }
            }
            catch { }
        }

        void OnFrame(object sender, NewFrameEventArgs e)
        {
            var copia = (Bitmap)e.Frame.Clone();
            lock (lk)
            {
                if (ultimoFrame != null) ultimoFrame.Dispose();
                ultimoFrame = copia;
            }
            if (estado != Estado.Capturando) return;
            if (Interlocked.Exchange(ref pintando, 1) == 1) return;

            var disp = (Bitmap)e.Frame.Clone();
            if (Config.Espejo) disp.RotateFlip(RotateFlipType.RotateNoneFlipX);
            try
            {
                BeginInvoke(new Action(() =>
                {
                    if (IsDisposed || estado != Estado.Capturando) { disp.Dispose(); }
                    else
                    {
                        var viejo = vista.Image;
                        vista.Image = disp;
                        if (viejo != null) viejo.Dispose();
                    }
                    Interlocked.Exchange(ref pintando, 0);
                }));
            }
            catch
            {
                disp.Dispose();
                Interlocked.Exchange(ref pintando, 0);
            }
        }

        Bitmap Capturar()
        {
            lock (lk)
            {
                return ultimoFrame == null ? null : (Bitmap)ultimoFrame.Clone();
            }
        }

        // ---------- Flujo ----------
        void IrAInicio()
        {
            timerRevision.Stop();
            estado = Estado.Inicio;
            if (tira != null) { tira.Dispose(); tira = null; }
            var viejo = vista.Image;
            vista.Image = null;
            if (viejo != null) viejo.Dispose();
            Mensaje("", 60);
            revision.SetTira(null);
            Pantalla();
        }

        async Task Sesion()
        {
            if (estado == Estado.Capturando) return;
            timerRevision.Stop();
            estado = Estado.Capturando;
            var anterior = vista.Image;
            vista.Image = null;
            if (anterior != null) anterior.Dispose();
            Pantalla();

            var fotos = new List<Bitmap>();
            try
            {
                int n = Config.NumFotos;
                var orden = Enumerable.Range(0, Graciosas.Length).OrderBy(x => rnd.Next()).ToList();
                for (int i = 1; i <= n; i++)
                {
                    Mensaje("Foto " + i + " de " + n, 70);
                    Task habla;
                    if (i == 1)
                    {
                        habla = Voz.Decir("¿Estás listo?", "listo");
                    }
                    else if (i == n)
                    {
                        habla = Voz.Decir("¡Última foto!", "ultima");
                    }
                    else
                    {
                        int k = orden[(i - 2) % orden.Count];
                        habla = Voz.Decir(Graciosas[k], "gracioso" + (k + 1));
                    }
                    await Task.WhenAll(Task.Delay(1500), habla);

                    for (int c = Config.Cuenta; c >= 1; c--)
                    {
                        Mensaje(c.ToString(), 200);
                        Voz.Hablar(c < Numeros.Length ? Numeros[c] : c.ToString(), "n" + c);
                        await Task.Delay(1000);
                    }
                    Mensaje("¡Sonríe!", 120);
                    await Task.Delay(300);

                    var f = Capturar();
                    if (f == null) throw new Exception("La cámara no está entregando imagen.");
                    fotos.Add(f);
                    await Flash();
                }

                Mensaje("¡Terminamos!", 100);
                Voz.Hablar("¡Terminamos!", "terminamos");
                await Task.Delay(1500);

                Mensaje("Preparando tu tira...", 60);
                var diseno = Disenos.Activo();
                var nueva = await Task.Run(() => Composicion.Crear(fotos, diseno));
                tira = nueva;
                await Task.Run(() => Guardar(fotos, nueva));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error:\n" + ex.Message, "FotoCabina");
                IrAInicio();
                return;
            }
            finally
            {
                foreach (var f in fotos) f.Dispose();
            }
            MostrarRevision();
        }

        async Task Flash()
        {
            Mensaje("", 60);
            vista.Visible = false;
            BackColor = Color.White;
            await Task.Delay(150);
            BackColor = Color.Black;
            vista.Visible = true;
        }

        void MostrarRevision()
        {
            estado = Estado.Revision;
            Mensaje("", 60);
            var viejo = vista.Image;
            vista.Image = null;
            if (viejo != null) viejo.Dispose();
            Pantalla();
            revision.Mensaje = "";
            revision.MostrarBotones = true;
            revision.SetTira(tira);
            revision.Iniciar();
            timerRevision.Interval = Config.SegundosRevision * 1000;
            timerRevision.Start();
        }

        void Guardar(List<Bitmap> fotos, Bitmap laTira)
        {
            var dir = Path.Combine(Config.CarpetaFotos, DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(dir);
            for (int i = 0; i < fotos.Count; i++)
                Composicion.GuardarJpg(fotos[i], Path.Combine(dir, "foto" + (i + 1) + ".jpg"));
            Composicion.GuardarJpg(laTira, Path.Combine(dir, "tira.jpg"));
        }

        // ---------- Impresion ----------
        void ImprimirTira()
        {
            if (tira == null) return;
            timerRevision.Stop();
            try
            {
                var imagen = (Bitmap)tira.Clone();
                bool angosta = imagen.Width * 2 < imagen.Height;
                bool duplicar = Config.DuplicarTira && angosta;
                if (!duplicar && (imagen.Width > imagen.Height) != (Config.PapelAncho > Config.PapelAlto))
                    imagen.RotateFlip(RotateFlipType.Rotate90FlipNone);
                var pd = new PrintDocument();
                if (Config.Impresora.Length > 0) pd.PrinterSettings.PrinterName = Config.Impresora;
                pd.DefaultPageSettings.Margins = new Margins(0, 0, 0, 0);
                pd.OriginAtMargins = false;
                pd.DefaultPageSettings.PaperSize = new PaperSize("Foto", Config.PapelAncho, Config.PapelAlto);
                pd.PrintPage += (s, e) =>
                {
                    var g = e.Graphics;
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    var pb = e.PageBounds;
                    if (duplicar)
                    {
                        float w = pb.Width / 2f;
                        g.DrawImage(imagen, 0, 0, w, pb.Height);
                        g.DrawImage(imagen, w, 0, w, pb.Height);
                    }
                    else
                    {
                        float esc = Math.Min(pb.Width / (float)imagen.Width, pb.Height / (float)imagen.Height);
                        float w = imagen.Width * esc, h = imagen.Height * esc;
                        g.DrawImage(imagen, (pb.Width - w) / 2, (pb.Height - h) / 2, w, h);
                    }
                    e.HasMorePages = false;
                };
                pd.EndPrint += (s, e) => imagen.Dispose();
                pd.Print();
                revision.MostrarBotones = false;
                revision.Mensaje = "Imprimiendo... ¡gracias!";
                var t = new System.Windows.Forms.Timer { Interval = 3000 };
                t.Tick += (s, e) => { t.Stop(); t.Dispose(); IrAInicio(); };
                t.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo imprimir:\n" + ex.Message, "FotoCabina");
                timerRevision.Start();
            }
        }
    }
}
