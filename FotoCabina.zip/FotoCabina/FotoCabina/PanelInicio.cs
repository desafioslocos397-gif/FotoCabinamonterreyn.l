﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace FotoCabina
{
    // Pantalla de inicio: skin de fondo + boton rojo que pulsa y brilla
    class PanelInicio : Control
    {
        Bitmap fondo, boton;
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval = 33 };
        readonly DateTime t0 = DateTime.Now;

        public PanelInicio()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Color.Black;
            boton = Recursos.Embebido("boton_inicio.png");
            RecargarSkin();
            timer.Tick += (s, e) => Invalidate();
            timer.Enabled = true;
            VisibleChanged += (s, e) => timer.Enabled = Visible;
        }

        public void RecargarSkin()
        {
            Bitmap nuevo = null;
            var ruta = Config.Skin;
            if (ruta.Length > 0 && File.Exists(ruta)) nuevo = Recursos.Archivo(ruta);
            if (nuevo == null) nuevo = Recursos.Embebido("fondo_inicio.jpg");
            var viejo = fondo;
            fondo = nuevo;
            if (viejo != null) viejo.Dispose();
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Color.Black);
            if (fondo == null) return;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            float esc = Math.Min(Width / (float)fondo.Width, Height / (float)fondo.Height);
            float w = fondo.Width * esc, h = fondo.Height * esc;
            var r = new RectangleF((Width - w) / 2f, (Height - h) / 2f, w, h);
            g.DrawImage(fondo, r);
            if (boton == null) return;

            double t = (DateTime.Now - t0).TotalSeconds;
            float p = (float)(0.5 + 0.5 * Math.Sin(t * 2 * Math.PI * 0.9));   // 0..1
            float diam = Math.Min(r.Height * 0.26f, r.Width * 0.35f) * (1f + 0.07f * p);
            float cx = r.X + r.Width * 0.4967f;
            float cy = r.Y + r.Height * 0.8418f;

            float gd = diam * 1.8f;
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(cx - gd / 2f, cy - gd / 2f, gd, gd);
                using (var pg = new PathGradientBrush(path))
                {
                    pg.CenterColor = Color.FromArgb((int)(90 + 110 * p), 255, 40, 40);
                    pg.SurroundColors = new[] { Color.FromArgb(0, 255, 40, 40) };
                    g.FillPath(pg, path);
                }
            }
            g.DrawImage(boton, cx - diam / 2f, cy - diam / 2f, diam, diam);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                timer.Dispose();
                if (fondo != null) fondo.Dispose();
                if (boton != null) boton.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
