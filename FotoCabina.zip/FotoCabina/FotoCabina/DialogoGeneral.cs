﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace FotoCabina
{
    class DialogoGeneral : Form
    {
        readonly NumericUpDown nFotos, nCuenta;
        readonly CheckBox cVoz, cImprimir;

        public DialogoGeneral()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Tema.Fondo;
            Size = new Size(760, 560);
            ShowInTaskbar = false;
            Paint += (s, e) => Tema.Borde(e.Graphics, Size);

            Controls.Add(new Label
            {
                Text = "CONFIGURACIÓN GENERAL", ForeColor = Tema.Dorado, Font = Tema.Fuente(24),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 15, Width, 60)
            });

            Etiqueta("FOTOS POR SESIÓN (1 a 4)", 100);
            Etiqueta("SEGUNDOS DE CUENTA", 180);
            Etiqueta("VOZ", 260);
            Etiqueta("PERMITIR IMPRIMIR", 340);

            nFotos = new NumericUpDown
            {
                Minimum = 1, Maximum = 4, Value = Config.NumFotos, Font = Tema.Fuente(20),
                Bounds = new Rectangle(460, 100, 130, 50), BackColor = Tema.Panel, ForeColor = Color.White
            };
            nCuenta = new NumericUpDown
            {
                Minimum = 1, Maximum = 10, Value = Config.Cuenta, Font = Tema.Fuente(20),
                Bounds = new Rectangle(460, 180, 130, 50), BackColor = Tema.Panel, ForeColor = Color.White
            };
            cVoz = new CheckBox
            {
                Checked = Config.Voz, Text = "Activada", ForeColor = Tema.DoradoClaro, Font = Tema.Fuente(18),
                AutoSize = true, Location = new Point(460, 262)
            };
            cImprimir = new CheckBox
            {
                Checked = Config.Imprimir, Text = "Sí", ForeColor = Tema.DoradoClaro, Font = Tema.Fuente(18),
                AutoSize = true, Location = new Point(460, 342)
            };
            Controls.Add(nFotos);
            Controls.Add(nCuenta);
            Controls.Add(cVoz);
            Controls.Add(cImprimir);

            var guardar = Tema.Boton("GUARDAR", (s, e) => { Guardar(); DialogResult = DialogResult.OK; }, 18);
            guardar.Bounds = new Rectangle(110, 450, 250, 70);
            var cancelar = Tema.Boton("CANCELAR", (s, e) => { DialogResult = DialogResult.Cancel; }, 18);
            cancelar.Bounds = new Rectangle(400, 450, 250, 70);
            Controls.Add(guardar);
            Controls.Add(cancelar);
        }

        void Etiqueta(string texto, int y)
        {
            Controls.Add(new Label
            {
                Text = texto, ForeColor = Tema.Texto, Font = Tema.Fuente(18),
                TextAlign = ContentAlignment.MiddleLeft, Bounds = new Rectangle(40, y, 400, 50)
            });
        }

        void Guardar()
        {
            Config.Set("NumFotos", ((int)nFotos.Value).ToString());
            Config.Set("Cuenta", ((int)nCuenta.Value).ToString());
            Config.Set("Voz", cVoz.Checked.ToString());
            Config.Set("Imprimir", cImprimir.Checked.ToString());
        }
    }
}
