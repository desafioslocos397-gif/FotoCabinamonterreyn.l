﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FotoCabina
{
    static class Config
    {
        // Ajustes guardados desde el menu (se guardan en AppData, no necesitan permisos de administrador)
        static readonly Dictionary<string, string> ini = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        static Config() { Cargar(); }

        public static string CarpetaApp { get { return AppDomain.CurrentDomain.BaseDirectory; } }
        public static string CarpetaDatos
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FotoCabina"); }
        }
        public static string CarpetaSkins { get { return Path.Combine(CarpetaDatos, "Skins"); } }
        public static string CarpetaDisenos { get { return Path.Combine(CarpetaDatos, "Disenos"); } }
        public static string CarpetaImagenes { get { return Path.Combine(CarpetaDatos, "Imagenes"); } }
        public static string CarpetaFondos { get { return Path.Combine(CarpetaDatos, "Fondos"); } }
        static string RutaIni { get { return Path.Combine(CarpetaDatos, "ajustes.ini"); } }

        static void Cargar()
        {
            try
            {
                if (!File.Exists(RutaIni)) return;
                foreach (var l in File.ReadAllLines(RutaIni, Encoding.UTF8))
                {
                    int i = l.IndexOf('=');
                    if (i > 0) ini[l.Substring(0, i).Trim()] = l.Substring(i + 1).Trim();
                }
            }
            catch { }
        }

        public static void Set(string clave, string valor)
        {
            ini[clave] = valor ?? "";
            try
            {
                Directory.CreateDirectory(CarpetaDatos);
                File.WriteAllLines(RutaIni, ini.Select(kv => kv.Key + "=" + kv.Value).ToArray(), Encoding.UTF8);
            }
            catch { }
        }

        static string S(string k, string d)
        {
            string v;
            if (ini.TryGetValue(k, out v) && v.Length > 0) return v;
            var a = ConfigurationManager.AppSettings[k];
            return string.IsNullOrWhiteSpace(a) ? d : a.Trim();
        }
        static int I(string k, int d)
        {
            int r;
            return int.TryParse(S(k, ""), out r) ? r : d;
        }
        static bool B(string k, bool d)
        {
            bool r;
            return bool.TryParse(S(k, ""), out r) ? r : d;
        }

        public static int NumFotos { get { return Math.Max(1, Math.Min(4, I("NumFotos", 3))); } }
        public static int Cuenta { get { return Math.Max(1, Math.Min(10, I("Cuenta", 3))); } }
        public static int Camara { get { return Math.Max(0, I("Camara", 0)); } }
        public static string Texto { get { return S("Texto", "Fotocabina"); } }
        public static bool Imprimir { get { return B("Imprimir", true); } }
        public static string Impresora { get { return S("Impresora", ""); } }
        public static bool DuplicarTira { get { return B("DuplicarTira", true); } }
        public static int PapelAncho { get { return I("PapelAncho", 400); } }
        public static int PapelAlto { get { return I("PapelAlto", 600); } }
        public static bool Espejo { get { return B("Espejo", true); } }
        public static int SegundosRevision { get { return Math.Max(10, I("SegundosRevision", 45)); } }
        public static bool Voz { get { return B("Voz", true); } }
        public static string DisenoActivo { get { return S("DisenoActivo", "@clasica"); } }
        public static int SegFondo { get { return Math.Max(3, Math.Min(60, I("SegFondo", 8))); } }
        public static bool FondoAuto { get { return B("FondoAuto", true); } }
        public static string FondosOff { get { return S("FondosOff", ""); } }
        public static string Skin { get { return S("Skin", ""); } }

        public static string CarpetaFotos
        {
            get
            {
                var c = S("CarpetaFotos", "");
                if (c.Length == 0)
                    c = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "FotoCabina");
                return c;
            }
        }

        // Teclas de los botones: 0 = Iniciar, 1 = Imprimir, 2 = Repetir, 3 = Terminar
        public static readonly string[] TeclaClaves = { "TeclaIniciar", "TeclaImprimir", "TeclaRepetir", "TeclaTerminar" };
        public static readonly Keys[] TeclaDefectos = { Keys.Space, Keys.P, Keys.R, Keys.T };

        public static Keys TeclaAccion(int i)
        {
            Keys k;
            return Enum.TryParse(S(TeclaClaves[i], TeclaDefectos[i].ToString()), true, out k) ? k : TeclaDefectos[i];
        }

        public static string NombreTecla(Keys k)
        {
            string s = k.ToString();
            if (s.Length == 2 && s[0] == 'D' && char.IsDigit(s[1])) return s.Substring(1);
            if (s.StartsWith("NumPad")) return "NUM " + s.Substring(6);
            switch (k)
            {
                case Keys.Space: return "ESPACIO";
                case Keys.Return: return "ENTER";
                case Keys.Escape: return "ESC";
                case Keys.ControlKey: return "CTRL";
                case Keys.ShiftKey: return "SHIFT";
                case Keys.Menu: return "ALT";
                case Keys.Up: return "FLECHA ARRIBA";
                case Keys.Down: return "FLECHA ABAJO";
                case Keys.Left: return "FLECHA IZQ.";
                case Keys.Right: return "FLECHA DER.";
            }
            return s.ToUpper();
        }
    }
}
