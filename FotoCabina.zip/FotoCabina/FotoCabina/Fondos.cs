﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;

namespace FotoCabina
{
    // Fondos de pantalla que cambian solos detras de la tira (pantalla de resultado)
    static class Fondos
    {
        public static readonly string[] Incluidos =
        {
            "@fondo_1.jpg", "@fondo_2.jpg", "@fondo_3.jpg", "@fondo_4.jpg", "@fondo_5.jpg", "@fondo_6.jpg"
        };
        static readonly string[] nombres =
        {
            "Oro brillante", "Confeti", "Rayos dorados", "Luces de fiesta", "Art deco", "Neón"
        };

        public static string Carpeta { get { return Config.CarpetaFondos; } }

        public static string Nombre(string id)
        {
            int i = Array.IndexOf(Incluidos, id);
            return i >= 0 ? nombres[i] : Path.GetFileNameWithoutExtension(id);
        }

        static bool EsImagen(string f)
        {
            var x = Path.GetExtension(f).ToLower();
            return x == ".jpg" || x == ".jpeg" || x == ".png" || x == ".bmp";
        }

        public static List<string> Todos()
        {
            var l = new List<string>(Incluidos);
            try
            {
                if (Directory.Exists(Carpeta))
                    l.AddRange(Directory.GetFiles(Carpeta).Where(EsImagen).OrderBy(x => x));
            }
            catch { }
            return l;
        }

        public static bool EstaActivo(string id)
        {
            var off = Config.FondosOff.Split('|');
            return Array.IndexOf(off, id) < 0;
        }

        public static void Activar(string id, bool activo)
        {
            var off = Config.FondosOff.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries).ToList();
            off.Remove(id);
            if (!activo) off.Add(id);
            Config.Set("FondosOff", string.Join("|", off.ToArray()));
        }

        public static List<string> Activos()
        {
            var l = Todos().Where(EstaActivo).ToList();
            if (l.Count == 0) l.Add(Incluidos[0]);
            return l;
        }

        public static Bitmap Cargar(string id)
        {
            return Recursos.Cargar(id);
        }
    }
}
