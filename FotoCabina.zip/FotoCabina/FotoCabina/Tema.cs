﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace FotoCabina
{
    static class Tema
    {
        public static readonly Color Fondo = Color.FromArgb(14, 14, 14);
        public static readonly Color Panel = Color.FromArgb(30, 30, 30);
        public static readonly Color Dorado = Color.FromArgb(212, 175, 55);
        public static readonly Color DoradoClaro = Color.FromArgb(245, 215, 110);
        public static readonly Color Texto = Color.FromArgb(235, 235, 235);

        public static Font Fuente(float tam, bool negrita = true)
        {
            return new Font("Segoe UI", tam, negrita ? FontStyle.Bold : FontStyle.Regular);
        }

        public static void Borde(Graphics g, Size s)
        {
            using (var p = new Pen(Dorado, 3))
                g.DrawRectangle(p, 1, 1, s.Width - 3, s.Height - 3);
        }

        public static Button Boton(string texto, EventHandler click, float tam)
        {
            var b = new Button
            {
                Text = texto,
                FlatStyle = FlatStyle.Flat,
                BackColor = Panel,
                ForeColor = Dorado,
                Font = Fuente(tam),
                TabStop = false,
                UseMnemonic = false,
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            b.FlatAppearance.BorderColor = Dorado;
            b.FlatAppearance.BorderSize = 2;
            b.FlatAppearance.MouseOverBackColor = Dorado;
            b.FlatAppearance.MouseDownBackColor = DoradoClaro;
            b.MouseEnter += (s, e) => { b.ForeColor = Color.Black; };
            b.MouseLeave += (s, e) => { b.ForeColor = Dorado; };
            if (click != null) b.Click += click;
            return b;
        }
    }

    static class Recursos
    {
        public static Bitmap Embebido(string nombre)
        {
            try
            {
                using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(nombre))
                {
                    if (s == null) return null;
                    using (var img = Image.FromStream(s)) return new Bitmap(img);
                }
            }
            catch { return null; }
        }

        public static Bitmap Cargar(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            return id[0] == '@' ? Embebido(id.Substring(1)) : Archivo(id);
        }

        public static Bitmap Archivo(string ruta)
        {
            try
            {
                using (var fs = new FileStream(ruta, FileMode.Open, FileAccess.Read))
                using (var img = Image.FromStream(fs)) return new Bitmap(img);
            }
            catch { return null; }
        }
    }
}
