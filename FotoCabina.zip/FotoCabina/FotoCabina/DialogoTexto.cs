﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace FotoCabina
{
    // Captura de texto con teclado en pantalla (sirve con pantalla tactil)
    class DialogoTexto : Form
    {
        readonly TextBox tb;
        readonly List<Button> letras = new List<Button>();
        Button btnMayus;
        bool mayus = true;

        public string Valor { get { return tb.Text.Trim(); } }

        public DialogoTexto(string titulo, string inicial)
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Tema.Fondo;
            Size = new Size(1040, 590);
            ShowInTaskbar = false;
            Paint += (s, e) => Tema.Borde(e.Graphics, Size);

            Controls.Add(new Label
            {
                Text = titulo, ForeColor = Tema.Dorado, Font = Tema.Fuente(22),
                TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(0, 10, Width, 50)
            });

            tb = new TextBox
            {
                Font = Tema.Fuente(26), Bounds = new Rectangle(40, 70, Width - 80, 50), Text = inicial,
                BackColor = Tema.Panel, ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle, MaxLength = 40
            };
            tb.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; DialogResult = DialogResult.OK; }
                else if (e.KeyCode == Keys.Escape) { e.SuppressKeyPress = true; DialogResult = DialogResult.Cancel; }
            };
            Controls.Add(tb);

            string[] filas = { "1234567890&", "QWERTYUIOP¡", "ASDFGHJKLÑ!", "ZXCVBNM.,-?", "ÁÉÍÓÚÜ'()+¿" };
            for (int r = 0; r < filas.Length; r++)
            {
                for (int c = 0; c < filas[r].Length; c++)
                {
                    var b = Tema.Boton(filas[r][c].ToString(), (s, e) => Escribir(((Button)s).Text), 18);
                    b.Bounds = new Rectangle(58 + c * 84, 135 + r * 64, 78, 58);
                    if (char.IsLetter(filas[r][c])) letras.Add(b);
                    Controls.Add(b);
                }
            }

            int x = 50, y = 470;
            btnMayus = Tema.Boton("MAYÚS", (s, e) => AlternarMayus(), 14);
            Agregar(btnMayus, ref x, y, 130);
            Agregar(Tema.Boton("ESPACIO", (s, e) => Escribir(" "), 14), ref x, y, 250);
            Agregar(Tema.Boton("BORRAR", (s, e) => Borrar(), 14), ref x, y, 120);
            Agregar(Tema.Boton("LIMPIAR", (s, e) => { tb.Text = ""; Foco(); }, 14), ref x, y, 120);
            var ok = Tema.Boton("ACEPTAR", null, 14);
            ok.DialogResult = DialogResult.OK;
            Agregar(ok, ref x, y, 140);
            var cancelar = Tema.Boton("CANCELAR", null, 14);
            cancelar.DialogResult = DialogResult.Cancel;
            Agregar(cancelar, ref x, y, 140);

            Shown += (s, e) => Foco();
        }

        void Agregar(Button b, ref int x, int y, int w)
        {
            b.Bounds = new Rectangle(x, y, w, 60);
            Controls.Add(b);
            x += w + 8;
        }

        void Escribir(string t) { tb.Text += t; Foco(); }

        void Borrar()
        {
            if (tb.Text.Length > 0) tb.Text = tb.Text.Substring(0, tb.Text.Length - 1);
            Foco();
        }

        void AlternarMayus()
        {
            mayus = !mayus;
            foreach (var l in letras) l.Text = mayus ? l.Text.ToUpper() : l.Text.ToLower();
            btnMayus.Text = mayus ? "MAYÚS" : "minús";
            Foco();
        }

        void Foco()
        {
            tb.Focus();
            tb.SelectionStart = tb.Text.Length;
        }
    }
}
