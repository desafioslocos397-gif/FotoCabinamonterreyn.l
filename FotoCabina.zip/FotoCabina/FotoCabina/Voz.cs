﻿using System;
using System.IO;
using System.Media;
using System.Speech.Synthesis;
using System.Threading.Tasks;

namespace FotoCabina
{
    // Voz: usa un archivo WAV de la carpeta "Voces" si existe (ej. listo.wav);
    // si no, usa la voz de Windows en espanol.
    static class Voz
    {
        static SpeechSynthesizer sint;
        static readonly object lk = new object();

        public static Task Decir(string texto, string wav)
        {
            if (!Config.Voz) return Task.FromResult(0);
            return Task.Run(() =>
            {
                try
                {
                    var ruta = Path.Combine(Config.CarpetaApp, "Voces", wav + ".wav");
                    lock (lk)
                    {
                        if (File.Exists(ruta))
                        {
                            using (var sp = new SoundPlayer(ruta)) sp.PlaySync();
                        }
                        else
                        {
                            if (sint == null) Crear();
                            sint.Speak(texto);
                        }
                    }
                }
                catch { }
            });
        }

        public static void Hablar(string texto, string wav)
        {
            Decir(texto, wav);
        }

        static void Crear()
        {
            sint = new SpeechSynthesizer();
            sint.Volume = 100;
            try
            {
                foreach (var v in sint.GetInstalledVoices())
                {
                    if (v.Enabled && v.VoiceInfo.Culture.TwoLetterISOLanguageName == "es")
                    {
                        sint.SelectVoice(v.VoiceInfo.Name);
                        break;
                    }
                }
            }
            catch { }
        }
    }
}
