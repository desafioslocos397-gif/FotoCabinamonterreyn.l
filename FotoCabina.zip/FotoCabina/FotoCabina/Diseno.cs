﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;

namespace FotoCabina
{
    // Un diseno de tira/postal: todo lo que el usuario puede editar
    class Diseno
    {
        public string Id = "";
        public string Nombre = "Nuevo diseño";
        public bool Incluido;                       // true = viene con el programa (no se edita directo)
        public string Tamano = "Tira";              // Tira, PostalV, PostalH, Cuadrada
        public string Distribucion = "Columna";     // Columna, Fila, Cuadricula
        public Color Fondo1 = Color.White;
        public Color Fondo2 = Color.White;
        public bool Degradado;
        public string ImagenFondo = "";
        public string Marco = "";
        public string Logo = "";
        public Color ColorTexto = Color.Black;
        public string Fuente = "Segoe UI";
        public bool MostrarNombre = true;
        public bool MostrarFecha = true;
        public string TextoExtra = "";
        public Color ColorBorde = Color.White;
        public int GrosorBorde;
        public int Esquinas;
        public int Margen = 30;
        public int Separacion = 30;
        public int AlturaPie = 240;

        public Size Dimensiones
        {
            get
            {
                switch (Tamano)
                {
                    case "PostalV": return new Size(1200, 1800);
                    case "PostalH": return new Size(1800, 1200);
                    case "Cuadrada": return new Size(1200, 1200);
                    default: return new Size(600, 1800);
                }
            }
        }

        public Diseno Clonar() { return (Diseno)MemberwiseClone(); }

        static string Hex(Color c) { return "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2"); }

        static Color ColorDe(string s, Color def)
        {
            try { return ColorTranslator.FromHtml(s); } catch { return def; }
        }

        public string Serializar()
        {
            var sb = new StringBuilder();
            Action<string, object> a = (k, v) => sb.AppendLine(k + "=" + v);
            a("Nombre", Nombre);
            a("Tamano", Tamano);
            a("Distribucion", Distribucion);
            a("Fondo1", Hex(Fondo1));
            a("Fondo2", Hex(Fondo2));
            a("Degradado", Degradado);
            a("ImagenFondo", ImagenFondo);
            a("Marco", Marco);
            a("Logo", Logo);
            a("ColorTexto", Hex(ColorTexto));
            a("Fuente", Fuente);
            a("MostrarNombre", MostrarNombre);
            a("MostrarFecha", MostrarFecha);
            a("TextoExtra", TextoExtra);
            a("ColorBorde", Hex(ColorBorde));
            a("GrosorBorde", GrosorBorde);
            a("Esquinas", Esquinas);
            a("Margen", Margen);
            a("Separacion", Separacion);
            a("AlturaPie", AlturaPie);
            return sb.ToString();
        }

        public static Diseno Leer(string id, string[] lineas)
        {
            var d = new Diseno { Id = id };
            foreach (var l in lineas)
            {
                int i = l.IndexOf('=');
                if (i <= 0) continue;
                string k = l.Substring(0, i).Trim();
                string v = l.Substring(i + 1).Trim();
                int n;
                bool b;
                switch (k)
                {
                    case "Nombre": d.Nombre = v; break;
                    case "Tamano": d.Tamano = v; break;
                    case "Distribucion": d.Distribucion = v; break;
                    case "Fondo1": d.Fondo1 = ColorDe(v, d.Fondo1); break;
                    case "Fondo2": d.Fondo2 = ColorDe(v, d.Fondo2); break;
                    case "Degradado": if (bool.TryParse(v, out b)) d.Degradado = b; break;
                    case "ImagenFondo": d.ImagenFondo = v; break;
                    case "Marco": d.Marco = v; break;
                    case "Logo": d.Logo = v; break;
                    case "ColorTexto": d.ColorTexto = ColorDe(v, d.ColorTexto); break;
                    case "Fuente": d.Fuente = v; break;
                    case "MostrarNombre": if (bool.TryParse(v, out b)) d.MostrarNombre = b; break;
                    case "MostrarFecha": if (bool.TryParse(v, out b)) d.MostrarFecha = b; break;
                    case "TextoExtra": d.TextoExtra = v; break;
                    case "ColorBorde": d.ColorBorde = ColorDe(v, d.ColorBorde); break;
                    case "GrosorBorde": if (int.TryParse(v, out n)) d.GrosorBorde = n; break;
                    case "Esquinas": if (int.TryParse(v, out n)) d.Esquinas = n; break;
                    case "Margen": if (int.TryParse(v, out n)) d.Margen = n; break;
                    case "Separacion": if (int.TryParse(v, out n)) d.Separacion = n; break;
                    case "AlturaPie": if (int.TryParse(v, out n)) d.AlturaPie = n; break;
                }
            }
            return d;
        }
    }

    // Lista de disenos: incluidos + los del usuario (carpeta AppData\FotoCabina\Disenos)
    static class Disenos
    {
        public static List<Diseno> Incluidos()
        {
            var l = new List<Diseno>();
            l.Add(new Diseno { Id = "@clasica", Nombre = "Clásica blanca", Incluido = true });
            l.Add(new Diseno
            {
                Id = "@dorada", Nombre = "Leon Booth dorada", Incluido = true,
                Fondo1 = Color.Black, ColorTexto = Color.FromArgb(245, 215, 110),
                ColorBorde = Color.FromArgb(212, 175, 55), GrosorBorde = 6,
                Margen = 30, Separacion = 24, AlturaPie = 380, Logo = "@logo_leon.png"
            });
            l.Add(new Diseno
            {
                Id = "@fiesta", Nombre = "Fiesta colorida", Incluido = true,
                Degradado = true, Fondo1 = Color.FromArgb(106, 17, 203), Fondo2 = Color.FromArgb(255, 64, 129),
                ColorTexto = Color.White, ColorBorde = Color.White, GrosorBorde = 8,
                Esquinas = 28, Margen = 36, Separacion = 28
            });
            l.Add(new Diseno
            {
                Id = "@postalv", Nombre = "Postal vertical 4x6", Incluido = true,
                Tamano = "PostalV", Distribucion = "Cuadricula",
                Fondo1 = Color.FromArgb(250, 245, 235), ColorTexto = Color.FromArgb(60, 40, 20),
                ColorBorde = Color.FromArgb(212, 175, 55), GrosorBorde = 6, Esquinas = 12,
                Margen = 40, Separacion = 30, AlturaPie = 220
            });
            l.Add(new Diseno
            {
                Id = "@postalh", Nombre = "Postal horizontal 6x4", Incluido = true,
                Tamano = "PostalH", Distribucion = "Fila",
                Fondo1 = Color.FromArgb(16, 24, 48), ColorTexto = Color.White,
                ColorBorde = Color.White, GrosorBorde = 6, Esquinas = 16,
                Margen = 40, Separacion = 30, AlturaPie = 200
            });
            return l;
        }

        public static List<Diseno> Usuario()
        {
            var l = new List<Diseno>();
            try
            {
                if (Directory.Exists(Config.CarpetaDisenos))
                {
                    foreach (var f in Directory.GetFiles(Config.CarpetaDisenos, "*.dis").OrderBy(x => x))
                        l.Add(Diseno.Leer(Path.GetFileNameWithoutExtension(f), File.ReadAllLines(f, Encoding.UTF8)));
                }
            }
            catch { }
            return l;
        }

        public static List<Diseno> Todos()
        {
            var l = Incluidos();
            l.AddRange(Usuario());
            return l;
        }

        public static Diseno Activo()
        {
            var id = Config.DisenoActivo;
            var todos = Todos();
            return todos.FirstOrDefault(d => d.Id == id) ?? todos[0];
        }

        public static void Guardar(Diseno d)
        {
            if (d.Incluido) return;
            if (string.IsNullOrEmpty(d.Id)) d.Id = "u_" + DateTime.Now.Ticks;
            Directory.CreateDirectory(Config.CarpetaDisenos);
            File.WriteAllText(Path.Combine(Config.CarpetaDisenos, d.Id + ".dis"), d.Serializar(), Encoding.UTF8);
        }

        public static void Eliminar(Diseno d)
        {
            if (d.Incluido) return;
            try { File.Delete(Path.Combine(Config.CarpetaDisenos, d.Id + ".dis")); } catch { }
            if (Config.DisenoActivo == d.Id) Config.Set("DisenoActivo", "@clasica");
        }

        // Copia la imagen elegida a la carpeta de datos (asi no se pierde si borran el original)
        public static string CopiarImagen(string origen)
        {
            Directory.CreateDirectory(Config.CarpetaImagenes);
            string dest = Path.Combine(Config.CarpetaImagenes, DateTime.Now.Ticks + Path.GetExtension(origen).ToLower());
            File.Copy(origen, dest, true);
            return dest;
        }

        // Fotos de ejemplo para las vistas previas
        public static List<Bitmap> Muestra(int n)
        {
            var l = new List<Bitmap>();
            Color[] cols =
            {
                Color.FromArgb(120, 170, 220), Color.FromArgb(220, 150, 170),
                Color.FromArgb(150, 200, 150), Color.FromArgb(230, 200, 120)
            };
            for (int i = 0; i < n; i++)
            {
                var b = new Bitmap(640, 480);
                using (var g = Graphics.FromImage(b))
                using (var br = new System.Drawing.Drawing2D.LinearGradientBrush(new Rectangle(0, 0, 640, 480), cols[i % 4], Color.FromArgb(40, 40, 60), 60f))
                using (var f = new Font("Segoe UI", 90, FontStyle.Bold))
                using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                {
                    g.FillRectangle(br, 0, 0, 640, 480);
                    g.DrawString("FOTO " + (i + 1), f, Brushes.White, new RectangleF(0, 0, 640, 480), sf);
                }
                l.Add(b);
            }
            return l;
        }
    }
}
